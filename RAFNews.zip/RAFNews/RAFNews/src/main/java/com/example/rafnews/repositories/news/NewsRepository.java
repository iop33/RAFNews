package com.example.rafnews.repositories.news;

import com.example.rafnews.entities.Comment;
import com.example.rafnews.entities.News;
import com.example.rafnews.entities.Tag;

import java.util.List;

public interface NewsRepository {
    List<News> allNews();
    List<News> allNewsByVisits();
    News addNews(News news);
    News updateNews(News news);
    News findNews(Integer id);
    void deleteNews(Integer id);
    List<News> allByCategory(Integer id);
    List<News> allByTag(Integer id);
    List<Tag> allTagByNews(Integer id);
    List<Comment> allCommentsByNews(Integer id);
}
