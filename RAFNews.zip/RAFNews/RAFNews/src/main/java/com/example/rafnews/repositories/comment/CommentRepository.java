package com.example.rafnews.repositories.comment;

import com.example.rafnews.entities.Comment;

import java.util.List;

public interface CommentRepository {
    List<Comment> allComments();
    Comment addComment(Comment comment);
    Comment findComment(Integer id);
    void deleteComment(Integer id);
}
