package com.example.rafnews.repositories.category;

import com.example.rafnews.entities.Category;
import com.example.rafnews.repositories.MySqlAbstractRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySqlCategoryRepository extends MySqlAbstractRepository implements CategoryRepository {

    @Override
    public List<Category> allCategory() {
        List<Category> categoryList = new ArrayList<>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM category");
            while (resultSet.next()) {
                Category category = new Category(resultSet.getInt("id"),resultSet.getString("categoryName"), resultSet.getString("categoryDescription"));
                categoryList.add(category);
            }
            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(statement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return categoryList;
    }

    @Override
    public Category addCategory(Category category) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();
            String[] generatedColumns={"id"};
            preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE category.categoryName = ? ");
            preparedStatement.setString(1, category.getCategoryName());
            resultSet = preparedStatement.executeQuery();

            if (!resultSet.next()) {
                preparedStatement = connection.prepareStatement("INSERT INTO category (categoryName, categoryDescription) VALUES (?,?)", generatedColumns);
                preparedStatement.setString(1, category.getCategoryName());
                preparedStatement.setString(2, category.getCategoryDescription());
                preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();
                if (resultSet.next()) {
                    category.setId(resultSet.getInt("id"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }
        return category;
    }

    @Override
    public Category updateCategory(Category category, String name) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();
            if (!(name.equals(category.getCategoryName()))) {
                preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE categoryName = ? ");
                preparedStatement.setString(1, category.getCategoryName());
                resultSet = preparedStatement.executeQuery();
            }
            if (resultSet == null || !resultSet.next() || name.equals(category.getCategoryName())) {
                preparedStatement = connection.prepareStatement("UPDATE category SET category.categoryName = ?, category.categoryDescription = ? WHERE category.categoryName = ?");
                preparedStatement.setString(1, category.getCategoryName());
                preparedStatement.setString(2, category.getCategoryDescription());
                preparedStatement.setString(3, name);
                preparedStatement.executeUpdate();
                preparedStatement.close();
                connection.close();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                this.closeResultSet(resultSet);
            }
            this.closeStatement(preparedStatement);
            this.closeConnection(connection);
        }
        return category;
    }


    @Override
    public Category findCategory(String name) {
        Category category = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE category.categoryName = ?");
            preparedStatement.setString(1, name);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String description = resultSet.getString("categoryDescription");
                Integer id=resultSet.getInt("id");
                category = new Category(id,name, description);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }
        return category;
    }

    @Override
    public void deleteCategory(String name) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("DELETE FROM category WHERE categoryName = ?");
            preparedStatement.setString(1, name);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeConnection(connection);
        }
    }
}
