package com.example.rafnews;

import com.example.rafnews.repositories.category.CategoryRepository;
import com.example.rafnews.repositories.category.MySqlCategoryRepository;
import com.example.rafnews.repositories.comment.CommentRepository;
import com.example.rafnews.repositories.comment.MySqlCommentRepository;
import com.example.rafnews.repositories.news.MySqlNewsRepository;
import com.example.rafnews.repositories.news.NewsRepository;
import com.example.rafnews.repositories.news_tag.MySqlNewsTagRepository;
import com.example.rafnews.repositories.news_tag.NewsTagRepository;
import com.example.rafnews.repositories.tag.MySqlTagRepository;
import com.example.rafnews.repositories.tag.TagRepository;
import com.example.rafnews.repositories.user.MySqlUserRepository;
import com.example.rafnews.repositories.user.UserRepository;
import com.example.rafnews.servicies.*;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;

import javax.inject.Singleton;
import javax.ws.rs.ApplicationPath;


@ApplicationPath("/api")
public class HelloApplication extends ResourceConfig {
    public HelloApplication() {
        property(ServerProperties.BV_SEND_ERROR_IN_RESPONSE, true);

        AbstractBinder binder = new AbstractBinder() {
            @Override
            protected void configure() {

                this.bind(MySqlUserRepository.class).to(UserRepository.class).in(Singleton.class);
                this.bind(MySqlTagRepository.class).to(TagRepository.class).in(Singleton.class);
                this.bind(MySqlCategoryRepository.class).to(CategoryRepository.class).in(Singleton.class);
                this.bind(MySqlCommentRepository.class).to(CommentRepository.class).in(Singleton.class);
                this.bind(MySqlNewsRepository.class).to(NewsRepository.class).in(Singleton.class);
                this.bind(MySqlNewsTagRepository.class).to(NewsTagRepository.class).in(Singleton.class);

                this.bindAsContract(NewsService.class);
                this.bindAsContract(UserService.class);
                this.bindAsContract(TagService.class);
                this.bindAsContract(CategoryService.class);
                this.bindAsContract(CommentService.class);
                this.bindAsContract(NewsTagService.class);
            }
        };
        register(binder);

        // Ucitavamo resurse
        packages("com.example.rafnews");
    }
}