package com.example.rafnews.repositories.tag;

import com.example.rafnews.entities.Tag;

import java.util.List;

public interface TagRepository {
    List<Tag> allTags();
    Tag addTag(Tag tag);
    Tag findTag(String id);
    Tag findTagById(Integer id);
    void deleteTag(Integer id);
}
