package com.example.rafnews.repositories.news;

import com.example.rafnews.entities.*;
import com.example.rafnews.repositories.MySqlAbstractRepository;
import com.example.rafnews.repositories.comment.CommentRepository;
import com.example.rafnews.repositories.tag.TagRepository;

import javax.inject.Inject;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MySqlNewsRepository extends MySqlAbstractRepository implements NewsRepository {
    @Inject
    private TagRepository tagRepository;
    @Inject
    private CommentRepository commentRepository;
    @Override
    public List<News> allNews() {
        List<News> newsList = new ArrayList<>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        ResultSet resultSetUser = null;
        ResultSet resultSetCategory = null;
        PreparedStatement preparedStatement = null;
        int i = 0;
        try {
            connection = this.newConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM news ORDER BY STR_TO_DATE(news.date, '%Y-%m-%d') DESC");
            while (i < 10 && resultSet.next()) {
                i++;
                News news = new News(resultSet.getInt("id"), resultSet.getString("title"), resultSet.getString("content"), resultSet.getString("date"));
                news.setVisits(resultSet.getInt("visits"));
                preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE id = ?");
                preparedStatement.setString(1, resultSet.getString("userId"));
                resultSetUser = preparedStatement.executeQuery();
                while (resultSetUser.next()) {
                    User user = new User(resultSetUser.getString("name"), resultSetUser.getString("surname"), resultSetUser.getString("email"), resultSetUser.getString("password"));
                    user.setStatus(resultSetUser.getInt("status"));
                    user.setRole(resultSetUser.getInt("role"));
                    synchronized (this) {
                        news.setUserId(user.getId());
                    }
                }
                preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE id = ?");
                preparedStatement.setInt(1, resultSet.getInt("categoryId"));
                resultSetCategory = preparedStatement.executeQuery();
                while (resultSetCategory.next()) {
                    Category category = new Category(resultSetCategory.getInt("id"),resultSetCategory.getString("categoryName"), resultSetCategory.getString("categoryDescription"));
                    synchronized (this) {
                        news.setCategoryId(category.getId());
                    }
                }
                newsList.add(news);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(statement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return newsList;
    }

    @Override
    public List<News> allNewsByVisits() {
        List<News> newsList = new ArrayList<>();
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        ResultSet resultSetUser = null;
        ResultSet resultSetCategory = null;
        int i = 0;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM news WHERE news.date BETWEEN NOW() - INTERVAL 30 DAY AND NOW() ORDER BY visits DESC");
            while (i < 10 && resultSet.next()) {
                i++;
                News news = new News(resultSet.getInt("id"), resultSet.getString("title"), resultSet.getString("content"),
                        resultSet.getString("date"));
                news.setVisits(resultSet.getInt("visits"));

                preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE email = ?");
                preparedStatement.setString(1, resultSet.getString("author"));
                resultSetUser = preparedStatement.executeQuery();

                while (resultSetUser.next()){
                    User user = new User(resultSetUser.getString("name"), resultSetUser.getString("surname"), resultSetUser.getString("email"), resultSetUser.getString("password"));
                    user.setStatus(resultSetUser.getInt("status"));
                    user.setRole(resultSetUser.getInt("role"));
                    synchronized (this) {
                        news.setUserId(user.getId());
                    }
                }
                preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE id = ?");
                preparedStatement.setInt(1, resultSet.getInt("categoryId"));
                resultSetCategory = preparedStatement.executeQuery();
                while (resultSetCategory.next()) {
                    Category category = new Category(resultSetCategory.getInt("id"),resultSetCategory.getString("categoryName"), resultSetCategory.getString("categoryDescription"));
                    synchronized (this) {
                        news.setCategoryId(category.getId());
                    }
                }
                newsList.add(news);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(statement);
            this.closeResultSet(resultSet);
            if (resultSetUser!=null){
                this.closeResultSet(resultSetUser);
            }
            if (resultSetCategory!=null){
                this.closeResultSet(resultSetCategory);
            }
            this.closeConnection(connection);
        }

        return newsList;
    }

    @Override
    public News addNews(News news) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ResultSet resultSetTag = null;
        try {
            connection = this.newConnection();
            String[] generatedColumns = {"id"};
            preparedStatement = connection.prepareStatement("INSERT INTO news (title, content, date, visits, userId, categoryId, author) VALUES(?, ?,?, ?,?,?,?)", generatedColumns);
            java.sql.Date sqlDate = new java.sql.Date(System.currentTimeMillis());
            preparedStatement.setString(1, news.getTitle());
            preparedStatement.setString(2, news.getContent());
            preparedStatement.setString(3, LocalDate.now().toString());
            preparedStatement.setInt(4, 0);
            preparedStatement.setInt(5, news.getUserId());
            preparedStatement.setInt(6, news.getCategoryId());
            preparedStatement.setString(7, news.getAuthor());
            preparedStatement.executeUpdate();
            resultSet = preparedStatement.getGeneratedKeys();
            if (resultSet.next()) {
                news.setId(resultSet.getInt(1));
            }

            for (Tag s: news.getTagList()) {
                preparedStatement = connection.prepareStatement("SELECT * FROM tag WHERE tagName = ?");
                preparedStatement.setString(1, s.getTagName());
                resultSetTag = preparedStatement.executeQuery();
                if (resultSetTag.next()) {
                    preparedStatement = connection.prepareStatement("INSERT INTO news_tag (newsForTagId, tagId) VALUES (?, ?)");
                    preparedStatement.setInt(1, news.getId());
                    preparedStatement.setInt(2, resultSetTag.getInt("id"));
                    preparedStatement.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            if (resultSet != null) {
                this.closeResultSet(resultSet);
            }
            this.closeConnection(connection);
        }
        return news;
    }

    @Override
    public News updateNews(News news) {

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("UPDATE news AS n SET n.title = ?, n.content = ?, " +
                    "n.userId = ?, n.categoryId = ?  where n.id = ?");
            preparedStatement.setString(1, news.getTitle());
            preparedStatement.setString(2, news.getContent());
            preparedStatement.setInt(3, news.getUserId());
            preparedStatement.setInt(4, news.getCategoryId());
            preparedStatement.setInt(5, news.getId());
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            if (resultSet != null) {
                this.closeResultSet(resultSet);
            }
            this.closeConnection(connection);
        }

        return news;
    }

    @Override
    public News findNews(Integer id) {

        News news = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ResultSet resultSetUser = null;
        ResultSet resultSetCategory = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM news where id = ?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String title = resultSet.getString("title");
                String content = resultSet.getString("content");
                String creationDate = resultSet.getString("date");
                Integer visits = resultSet.getInt("visits");
                preparedStatement = connection.prepareStatement("UPDATE news SET news.visits = news.visits + 1 WHERE news.id = ?");
                preparedStatement.setInt(1, id);
                preparedStatement.executeUpdate();
                news = new News(id, title, content, creationDate, visits);
                preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE id = ?");
                preparedStatement.setString(1, resultSet.getString("userId"));
                resultSetUser = preparedStatement.executeQuery();
                while (resultSetUser.next()) {
                    User user = new User(resultSetUser.getString("name"), resultSetUser.getString("surname"), resultSetUser.getString("email"), resultSetUser.getString("password"));
                    user.setStatus(resultSetUser.getInt("status"));
                    user.setRole(resultSetUser.getInt("role"));
                    synchronized (this) {
                        news.setUserId(user.getId());
                    }
                }
                preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE id = ?");
                preparedStatement.setString(1, resultSet.getString("categoryId"));
                resultSetCategory = preparedStatement.executeQuery();
                while (resultSetCategory.next()){
                    Category category = new Category(resultSetCategory.getInt("id"),resultSetCategory.getString("categoryName"), resultSetCategory.getString("categoryDescription"));
                    synchronized (this) {
                        news.setCategoryId(category.getId());
                    }
                }
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return news;
    }

    @Override
    public void deleteNews(Integer id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();

            preparedStatement = connection.prepareStatement("DELETE FROM news_tag WHERE newsForTagId = ?");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            preparedStatement = connection.prepareStatement("DELETE FROM comments WHERE newsId = ?");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

            preparedStatement = connection.prepareStatement("DELETE FROM news WHERE id = ?");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();




            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeConnection(connection);
        }
    }

    @Override
    public List<News> allByCategory(Integer id) {

        List<News> newsList = new ArrayList<>();
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM news WHERE categoryId LIKE ? ORDER BY STR_TO_DATE(news.date, '%Y-%m-%d') DESC");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                News news = new News(resultSet.getInt("id"), resultSet.getString("title"),
                        resultSet.getString("content"), resultSet.getString("date"));
                news.setVisits(resultSet.getInt("visits"));
                newsList.add(news);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }
        return newsList;
    }

    @Override
    public List<News> allByTag(Integer id) {
        List<News> newsList = new ArrayList<>();
        News news = null;
        Connection connection = null;
        ResultSet resultSet = null;
        ResultSet resultSet1 = null;
        ResultSet resultSetUser = null;
        ResultSet resultSetCategory = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM news_tag WHERE newsForTagId = ?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Integer idNews = resultSet.getInt("newsForTagId");
                preparedStatement = connection.prepareStatement("SELECT * FROM news WHERE id = ? ");
                preparedStatement.setInt(1, idNews);
                resultSet1 = preparedStatement.executeQuery();
                if (resultSet1.next()) {
                    String title = resultSet1.getString("title");
                    String content = resultSet1.getString("content");
                    String createdAt = resultSet1.getString("date");
                    Integer visits = resultSet1.getInt("visits");
                    news = new News(idNews, title, content, createdAt, visits);
                    preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE id = ?");
                    preparedStatement.setString(1, resultSet1.getString("userId"));
                    resultSetUser = preparedStatement.executeQuery();
                    while (resultSetUser.next()) {
                        User user = new User(resultSetUser.getString("name"), resultSetUser.getString("surname"), resultSetUser.getString("email"), resultSetUser.getString("password"));
                        user.setStatus(resultSetUser.getInt("status"));
                        user.setRole(resultSetUser.getInt("role"));

                        synchronized (this) {
                            news.setUserId(user.getId());
                        }
                    }
                    preparedStatement = connection.prepareStatement("SELECT * FROM category WHERE id = ?");
                    preparedStatement.setString(1, resultSet1.getString("categoryId"));
                    resultSetCategory = preparedStatement.executeQuery();
                    while (resultSetCategory.next()){
                        Category category = new Category(resultSetCategory.getInt("id"),resultSetCategory.getString("categoryName"), resultSetCategory.getString("categoryDescription"));
                        synchronized (this) {
                            news.setCategoryId(category.getId());
                        }
                    }
                }
                newsList.add(news);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return newsList;
    }

    @Override
    public List<Tag> allTagByNews(Integer id) {

        List<Tag> tagList = new ArrayList<>();
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM news_tag WHERE newsForTagId = ?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Tag tag = tagRepository.findTagById(resultSet.getInt("newsForTagId"));
                tagList.add(tag);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }
        return tagList;
    }

    @Override
    public List<Comment> allCommentsByNews(Integer id) {

        List<Comment> tagList = new ArrayList<>();
        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM comments WHERE newsId = ?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Comment comment = commentRepository.findComment(resultSet.getInt("id"));
                tagList.add(comment);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }
        return tagList;
    }
}
