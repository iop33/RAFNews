package com.example.rafnews.repositories.news_tag;

import com.example.rafnews.entities.News;
import com.example.rafnews.entities.Tag;

import java.util.List;

public interface NewsTagRepository {
    public void addTagToNews(Integer news_id, Integer tag_id);
    void removeTagFromNews(Integer news_id, Integer tag_id);
    List<Tag> allTagsForNews(Integer news_id);
    List<News> allNewsForTag(Integer tag_id);
}
