package com.example.rafnews.resources;

import com.example.rafnews.entities.News;
import com.example.rafnews.entities.Tag;
import com.example.rafnews.servicies.NewsTagService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/newstag")

public class NewsTagResource {
    @Inject
    private NewsTagService newsTagService;

    @GET
    @Path("/add/{news}/{tag}")
    @Produces(MediaType.APPLICATION_JSON)
    public void add(@PathParam("news") Integer news, @PathParam("tag") Integer tag){
        this.newsTagService.add(news, tag);
    }

    @GET
    @Path("/delete/{news}/{tag}")
    @Produces(MediaType.APPLICATION_JSON)
    public void delete(@PathParam("news") Integer news, @PathParam("tag") Integer tag){
        this.newsTagService.remove(news, tag);
    }

    @GET
    @Path("/all/{news}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Tag> all(@PathParam("news") Integer id) {
        return this.newsTagService.all(id);
    }

    @GET
    @Path("/news/{tag}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<News> allNews(@PathParam("tag") Integer tag) { return this.newsTagService.allNews(tag); }

}
