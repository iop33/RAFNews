package com.example.rafnews.repositories.news_tag;

import com.example.rafnews.entities.News;
import com.example.rafnews.entities.Tag;
import com.example.rafnews.repositories.MySqlAbstractRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MySqlNewsTagRepository extends MySqlAbstractRepository implements NewsTagRepository {

    @Override
    public void addTagToNews(Integer news_id, Integer tag_id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("INSERT INTO news_tag (newsForTagId, tagId) VALUES (?, ?)");
            preparedStatement.setInt(1, news_id);
            preparedStatement.setInt(2, tag_id);
            preparedStatement.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeConnection(connection);
        }
    }

    @Override
    public void removeTagFromNews(Integer news_id, Integer tag_id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try{
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("DELETE FROM news_tag WHERE newsForTagId = ? AND tagId = ?");
            preparedStatement.setInt(1, news_id);
            preparedStatement.setInt(2, tag_id);
            preparedStatement.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeConnection(connection);
        }
    }

    @Override
    public List<Tag> allTagsForNews(Integer news_id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ResultSet resultSetTags = null;
        List<Tag> tagList = new ArrayList<>();
        List<Integer> tagids = new ArrayList<>();
        try{
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM news_tag WHERE newsForTagId = ?");
            preparedStatement.setInt(1, news_id);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                tagids.add(resultSet.getInt("tagId"));
            }
            for (Integer id : tagids){
                preparedStatement = connection.prepareStatement("SELECT * FROM tag WHERE id = ?");
                preparedStatement.setInt(1, id);
                resultSetTags = preparedStatement.executeQuery();
                if(resultSetTags.next()){
                    tagList.add( new Tag(resultSetTags.getInt(1), resultSetTags.getString("tagName")));
                }
            }
        } catch(Exception e){
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            if (resultSet != null) {
                this.closeResultSet(resultSet);
            }
            if (resultSetTags != null) {
                this.closeResultSet(resultSetTags);
            }
            this.closeConnection(connection);
        }
        return tagList;
    }

    @Override
    public List<News> allNewsForTag(Integer tag_id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ResultSet resultSet2 = null;
        List<Integer> newsIDs = new ArrayList<>();
        List<News> newsList = new ArrayList<>();
        try{
            connection = this.newConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM news_tag WHERE tagId = ?");
            preparedStatement.setInt(1, tag_id);
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                newsIDs.add( resultSet.getInt("newsForTagId"));
            }
            for (Integer id : newsIDs){
                preparedStatement = connection.prepareStatement("SELECT * FROM news WHERE id = ?");
                preparedStatement.setInt(1, id);
                resultSet2 = preparedStatement.executeQuery();
                if (resultSet2.next()){
                    newsList.add(new News(resultSet2.getInt(1), resultSet2.getString("title"), resultSet2.getString("content"), resultSet2.getString("date")));
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            if (resultSet != null) {
                this.closeResultSet(resultSet);
            }
            if (resultSet2 != null) {
                this.closeResultSet(resultSet2);
            }
            this.closeConnection(connection);
        }


        return newsList;
    }
}
