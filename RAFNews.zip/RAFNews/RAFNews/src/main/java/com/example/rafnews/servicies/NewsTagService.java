package com.example.rafnews.servicies;

import com.example.rafnews.entities.News;
import com.example.rafnews.entities.Tag;
import com.example.rafnews.repositories.news_tag.NewsTagRepository;

import javax.inject.Inject;
import java.util.List;

public class NewsTagService {
    @Inject
    NewsTagRepository newsTagRepository;

    public void add(Integer newsId, Integer tagId) { this.newsTagRepository.addTagToNews(newsId, tagId); }
    public void remove(Integer newsId, Integer tagId) { this.newsTagRepository.removeTagFromNews(newsId, tagId); }
    public List<Tag> all(Integer newsId){ return this.newsTagRepository.allTagsForNews(newsId); }
    public List<News> allNews(Integer tagId) { return this.newsTagRepository.allNewsForTag(tagId); }
}
