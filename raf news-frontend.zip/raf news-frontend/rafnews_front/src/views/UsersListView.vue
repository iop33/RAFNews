<template>
    <div class="news" style="text-align: center">
    <h1 class="mt-4">All users</h1>
    <button class="btn btn-success" @click="addUsr">Add user</button>
    <hr>
    <br>

    <div class="row" style="display:inline;">
      <div class="col-4 mx-auto" >
        <table class=" table text-center" style="width: 650px;margin-left: -150px; border: 2px solid black;">
          <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Role</th>
            <th scope="col">Status</th>
            <th scope="col">Change Status</th>
            <th scope="col">Edit</th>
            <th scope="col">Delete</th>
          </tr>
          </thead>
          <tbody >
            <tr v-for="user in usersList" :key="user.id">
              <b-card style="margin-top: 10px">
                <td>{{ user.id }}</td>
                
              </b-card>
              <td>{{user.name }} {{ user.surname }}</td>
                <td>{{user.role | roleFilter }}</td>
                <td>
                    {{ user.status }}
                </td>
                <td>
                    <button class="btn btn-outline-secondary" @click="changeStatus(user.email)">Change Status</button>
                </td>
                <td><button class="btn btn-info" @click="editUser(user.email)">Edit</button></td>
                <td><button class="btn btn-danger" @click="deleteUser(user.email)">Delete</button></td>
              <!-- <td>{{ category.categoryDescription }}</td> -->
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</template>
<script>
export default({
    data(){
        return{
      usersList: []
        }
    },
mounted(){
    this.$axios.get('/api/users').then((response) => {
      this.usersList = response.data;
      console.log(response)
    });
},
methods: {
    addUsr(){
        console.log('adduser');
        this.$router.push('/users/add');
    },
    deleteUser(email){
        this.$axios.delete('/api/users/delete/'+email).then(( response => {
            console.log(response.data);
            window.location.reload();
        }))
    },
    creator(role){
        if (role == 0) return true;
    },
    changeStatus(email){
        this.$axios.get('/api/users/status/'+email).then((response => {
            console.log(response.data);
            window.location.reload();
        }))
    },
    editUser(email){
        this.$router.push('/users/edit/'+email);
    }
    
},
filters: {
    roleFilter(value){
        if (value == 1){
            return 'Admin';
        }
        return 'Content Creator';
    }
}

})

</script>
<style scoped>
.title{
  cursor: pointer;
}
.btn-success{
  margin: 12px;
}

</style>