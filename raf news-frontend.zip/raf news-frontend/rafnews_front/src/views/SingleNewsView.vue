<template>
    <ComponentNews :news="news"/>
</template>
<script>
import ComponentNews from '../components/ComponentNews.vue';
export default({
    components: {ComponentNews},
    data(){
        return{
            news: {}
        }
    },
    mounted(){
        let id = this.$route.params.id;
        this.$axios.get('/api/news/'+id).then((response => {
            this.news = response.data;
            const nID = this.news.id;
            console.log(JSON.stringify(this.news));
            this.$axios.get('/api/newstag/all/'+nID).then((response2 => {
                console.log(response2.data);
                const tags = response2.data;
                this.news.tags = tags;
            }));
        }));
    }
})

</script>

<style scoped>
</style>