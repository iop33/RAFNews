<template>
    <div class="pt-5">
      <form @submit.prevent="addTag" >
        <div class="form-group">
          <label for="tag">Tag name</label>
          <input v-model="tagName" type="text" class="form-control" id="tag" placeholder="Enter tag name">
        </div>
        <button type="submit" class="btn btn-success mt-2">Add Tag</button>
      </form>
    </div>
  </template>
  
  <script>
   export default({
    data(){
        return{
            tagName: ''
        }
    },
    methods: {
        addTag(){
            if (this.tagName.length > 0){
                this.$axios.post('/api/tags', {
                    tagName: this.tagName
                }).then((response => {
                    this.$router.push('/creatornews');
                }));    
            } else {
                alert("Tag name cannot be empty!");
                return;
            }
        }
    }
   })
  </script>
  
  <style scoped>
  
  </style>