<template>
    <div class="pt-5">
        <button class="btn btn-outline-success" @click="goToCategories">View all categories</button>
      <form @submit.prevent="login" >
        <div class="form-group">
          <label for="name">Name</label>
          <input v-model="name" type="text" class="form-control" id="name" placeholder="Enter name">
        <div class="form-group">
          <label for="desc">Description</label>
          <input v-model="desc" type="text" class="form-control" id="desc" placeholder="Description">
        </div>
        <button type="submit" class="btn btn-primary mt-2">Edit category</button>
        </div>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    name: "Login",
    data() {
      return {
        name: '',
        desc: '',
        jwt: '',
        oldName: ''
      }
    },
    methods: {
      login() {
        if (this.name.length == 0  || this.desc.length == 0){
            alert("Invalid fields!")
            return;
        }
        this.$axios.post('/api/category/'+this.oldName, {
          categoryName: this.name,
          categoryDescription: this.desc,
        }).then((response) => {
          console.log(response.data);
          this.$router.push({name: 'Categories'});
        }, () => {
         alert("Invalid fields!")
        })
      },
      goToCategories(){
        this.$router.push({name: 'Categories'});
      }
    },
    mounted(){
        let name = this.$route.params.id;
        this.$axios.get('/api/category/'+name).then((response => {
            const c = response.data;
            this.name = c.categoryName;
            this.oldName = c.categoryName;
            this.desc = c.categoryDescription;
        }));
    }
  }
  </script>
  
  <style scoped>
  .btn-outline-success{
    margin: 12px;
  }
  </style>