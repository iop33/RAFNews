<template>
    <div class="pt-5">
        <form @submit.prevent="addNews">
            <div class="form-group">
                <label for="title">Title</label>
                <input v-model="title" type="text" class="form-control" id="title" placeholder="Enter title">
            </div>
            <div class="form-group">
                <label for="content">Content</label>
                <textarea v-model="content" type="text" class="form-control" id="content"
                    placeholder="Enter news content"></textarea>
            </div>
            <div class="form-group" style="margin-top: 16px;">
                <b-form-select v-model="selected" :options="options"></b-form-select>
            </div>
            <b-form-group label="Select tags:" v-slot="{ ariaDescribedby }" style="margin: 16px ;">
                <b-form-checkbox-group id="checkbox-group-1" v-model="selectedTags" :options="optionsTags"
                    :aria-describedby="ariaDescribedby" name="flavour-1"></b-form-checkbox-group>
            </b-form-group>
            <button type="submit" class="btn btn-success mt-2">Add News</button>
        </form>
    </div>
</template>
  
<script>
export default {
    name: "AddNews",
    data() {
        return {
            title: '',
            content: '',
            jwt: '',
            selected: null,
            options: [
                { value: null, text: 'Select category type' }
            ],
            selectedTags: [],
            optionsTags: []
        }
    },
    methods: {
        addNews() {
            const jwt = localStorage.getItem('auth');

            const payload = JSON.parse(atob(jwt.split('.')[1]));

            let user = payload.sub;
            const userID = payload.id;
            user = user.replaceAll("\"", "");
            this.$axios.post('/api/news', {
                title: this.title,
                content: this.content,
                author: user,
                visits: 0,
                categoryId: this.selected,
                userId: userID
            }).then((response => {
                const d = response.data;
                console.log("USO U THEN");
                console.log("tags: " + this.selectedTags);
                for (const tag of this.selectedTags){
                            console.log("DODAJEM TAG");
                            this.$axios.get('/api/newstag/add/'+d.id+'/'+tag);
                }
            })).then((response2 => {
                 this.$router.push('/newscreator');
            }));
        }
    },
    mounted() {
        this.$axios.get('/api/category').then((response => {
            const data = response.data;
            for (const c of data) {
                this.options.push(new Object({
                    value: c.id,
                    text: c.categoryName
                }));
            }
        }));
        this.$axios.get('/api/tags').then((response => {
            const tagdata = response.data;
            for (const t of tagdata) {
                this.optionsTags.push(new Object({
                    value: t.id,
                    text: t.tagName
                }))
            }
        }));
    }
}
</script>
  
<style scoped>
.pt-5 {
    text-align: center;
}
</style>