<template>
    <div class="news" style="text-align: center">
    <h1 class="mt-4">News</h1>

    <div class="row" style="display:inline;">
      <div class="col-4 mx-auto" >
        <button class="btn btn-outline-success" @click="addNews" style="margin-bottom: 12px;">Add News</button>
        
        <table class=" table text-center table-bordered" style="width: 650px;margin-left: -150px; border: 1px solid black;">
          <thead>
          <tr>
            <th scope="col">Title</th>
            <th scope="col">Created At</th>
            <th scope="col">Content</th>
            <th scope="col">Edit</th>
            <th scope="col">Delete</th>
            <th scope="col">ID</th>
          </tr>
          </thead>
          <tbody >
            <tr v-for="news in newsList" :key="news.id" @click="find(news.id)">
              <!-- <b-card style="margin-top: 10px"> -->
              <td scope="row" @click="goToNews(news.id)" class="title"><b> {{ news.title }}</b></td>
              <!-- </b-card> -->
              <td>{{news.creationDate }}</td>
              <td>{{ news.content | shortText }}</td>
              <td><button class="btn btn-outline-secondary" @click="editNews(news.id)">Edit</button></td>
              <td><button class="btn btn-outline-danger" @click="deleteNews(news.id)">Delete</button></td>
              <td>{{ news.id }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</template>
<script>
export default({
    data(){
        return{
            selectedNews: null,
      newsList: []
        }
    },
    filters: {
    shortText(value) {
      if (value.length < 30) {
        return value;
      }
      return value.slice(0, 30) + '...'
    }
},
mounted(){
    this.$axios.get('/api/news').then((response) => {
      this.newsList = response.data;
      console.log(response)
    });
},
methods: {
    goToNews(id){
        this.$router.push('/news/'+id);
    },
    editNews(id){
      this.$router.push('/news/edit/'+id);
    },
    deleteNews(id){
        this.$axios.delete('/api/news/'+id).then((response => {
            window.location.reload();
        }));
    },
    addNews(){
        this.$router.push({name: 'AddNews'});
    }
}

})

</script>
<style scoped>
.title{
    cursor: pointer;
}
</style>