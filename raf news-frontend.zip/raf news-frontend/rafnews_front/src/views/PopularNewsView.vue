<template>
    <div class="news" style="text-align: center">
    <h1 class="mt-4">News</h1>

    <div class="row" style="display:inline;">
      <div class="col-4 mx-auto" >
        <table class=" table text-center" style="width: 650px;margin-left: -150px;">
          <thead>
          <tr>
            <th scope="col">Title</th>
            <th scope="col">Created At</th>
            <th scope="col">Content</th>
          </tr>
          </thead>
          <tbody >
            <tr v-for="news in newsList" :key="news.id" @click="goToNews(news.id)">
              <b-card style="margin-top: 10px">
              <td scope="row"> {{ news.title }}</td>
              </b-card>
              <td>{{news.creationDate }}</td>
              <td>{{ news.content | shortText }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</template>
<script>
export default({
    data(){
        return{
            selectedNews: null,
      newsList: []
        }
    },
    filters: {
    shortText(value) {
      if (value.length < 30) {
        return value;
      }
      return value.slice(0, 30) + '...'
    }
},
mounted(){
    this.$axios.get('/api/news/visits').then((response) => {
      this.newsList = response.data;
      console.log(response)
    });
},
methods: {
    goToNews(id){
        this.$router.push('/news/'+id);
    }
  }

})

</script>
<style>

</style>