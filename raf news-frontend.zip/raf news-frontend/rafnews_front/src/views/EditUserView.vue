<template>
    <div class="pt-5">
        <h1>Edit User</h1>
        <form @submit.prevent="editUser">
            <div class="form-group">
                <label for="email">Email</label>
                <input v-model="email" type="text" class="form-control" id="email" aria-describedby="emailHelp"
                    placeholder="Enter email">
            </div>
            <div class="form-group">
                <label for="fname">First Name</label>
                <input v-model="fname" type="text" class="form-control" id="fname"
                    placeholder="Enter first name">
            </div>
            <div class="form-group">
                <label for="lname">Last Name</label>
                <input v-model="lname" type="text" class="form-control" id="lname" 
                    placeholder="Enter last name">
            </div>
            <div class="form-group" style="margin-top: 12px;">
                <b-form-select v-model="selected" :options="options"></b-form-select>
            </div>
            <button type="button" class="btn btn-danger mt-2" style="margin-right: 8px;" @click="goBack">Cancel</button>
            <button type="submit" class="btn btn-outline-success mt-2">Edit User</button>
        </form>
    </div>
</template>
  
<script>
export default {
    name: "AddUser",
    data() {
        return {
            email: '',
            password: '',
            fname: '',
            lname: '',
            jwt: '',
            selected: null,
            options: [
                { value: null, text: 'Select user type'},
                { value: 1, text: 'Admin'},
                { value: 0, text: 'Content Creator'}
            ]
        }
    },
    mounted(){
        let email = this.$route.params.id;
        this.$axios.get('/api/users/'+email).then((response => {
            const user = response.data;
            this.email = user.email;
            this.fname = user.name;
            this.lname = user.surname;
            this.selected = user.role;
        }));
    },
    methods: {
        editUser() {
            if (this.fname.length == 0 || this.lname.length == 0 || this.email.length == 0  || this.selected == null){
                alert("All fields are required!");
                return;
            }
            let status = 0;
            if (this.selected == 1){
                status = 1;
            }
            console.log("aaaaa");
            let usr = this.$route.params.id;
            this.$axios.post('/api/users/'+usr, {
                email: this.email,
                name: this.fname,
                surname: this.lname,
                role: this.selected
            }).then((response => {
                this.$router.push('/users');
            }))
        },
        goBack(){
            this.$router.push('/users');
        }
    }
}
</script>
  
<style scoped>
.pt-5{
    text-align: center;
}
</style>