<template>
    <div class="news" style="text-align: center">
    <h1 class="mt-4">All categories</h1>
    <button class="btn btn-success" @click="addCat">Add category</button>
    <hr>
    <br>

    <div class="row" style="display:inline;">
      <div class="col-4 mx-auto" >
        <table class=" table text-center" style="width: 650px;margin-left: -150px; border: 2px solid black;">
          <thead>
          <tr>
            <th scope="col">Title</th>
            <th scope="col">Description</th>
          </tr>
          </thead>
          <tbody >
            <tr v-for="category in categoryList" :key="category.id">
              <b-card style="margin-top: 10px">
                <td @click="editCategory(category.categoryName)" class="title">{{category.categoryName }}</td>
              </b-card>
              <td>{{ category.categoryDescription }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</template>
<script>
export default({
    data(){
        return{
      categoryList: []
        }
    },
mounted(){
    this.$axios.get('/api/category').then((response) => {
      this.categoryList = response.data;
      console.log(response)
    });
},
methods: {
    editCategory(name){
        this.$router.push('/categories/edit/'+name);
    },
    addCat(){
      this.$router.push('/categories/add');
    }
}

})

</script>
<style scoped>
.title{
  cursor: pointer;
}
.btn-success{
  margin: 12px;
}

</style>