<template>
    <div class="news">
        <h1>{{ news.title }}</h1>
        <p>{{ news.creationDate }}</p>
        <p>{{ news.author }}</p>
        <p> {{ news.content }}</p>
        <div class="tags">
            <h4>Tags: </h4>
            <button class="btn btn-outline-info" v-for="tag in tags" :key="tag.id" @click="withTag(tag.id)">{{ tag.tagName }}</button>
        </div>
        <div class="commentsform" style="margin: 24px;">
            <h2>Add coment</h2>
            <b-form inline @submit.prevent="addComent">
                <b-form-input id="inline-form-input-name" class="mb-2 mr-sm-2 mb-sm-0" placeholder="Name"
                    v-model="commentName"></b-form-input>
                <textarea v-model="commentText" type="text" class="form-control" id="content"
                    placeholder="Enter comment content"></textarea>
                <b-button variant="primary" type="submit">Post</b-button>
            </b-form>
        </div>
        <div class="row" style="display:inline;">
            <h2>Comments</h2>
            <div class="col-4 mx-auto" ></div>
            <table class=" table text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Comment</th>
            <th scope="col">Posted At</th>
          </tr>
          </thead>
          <tbody >
            <tr v-for="comment in comments" :key="comment.id">
              <td scope="row"> {{ comment.author }}</td>
              <td>{{comment.content }}</td>
              <td>{{ comment.creationDate  }}</td>
            </tr>
          </tbody>
        </table>
        </div>
        </div>
    
</template>
<script>
export default ({
    name: 'ComponentNews',
    props: {
        news: {
            type: Object
        }
    },
    data() {
        return {
            tags: [],
            commentName: '',
            commentText: '',
            comments: []
        }
    },
    mounted() {
        let id = this.$route.params.id;
        this.$axios.get('/api/newstag/all/' + id).then((response => {
            // let data = response.data;
            this.tags = response.data;
            console.log(response.data);
        }));
        this.$axios.get('/api/comments').then((response => {
            const c = response.data;
            console.log("Komentari: "+JSON.stringify(response.data));
            for (const comm of response.data){
                console.log("Uso u for " + JSON.stringify(comm) + "newsId: " + comm.newsId);
                if (comm.newsId == id){
                    this.comments.push(comm);
                }
            }
        }));
    },
    methods: {
        addComent() {
            if (this.commentName.length == 0 || this.commentText == 0){
                alert("Comment name and text cannot be empty!");
                return;
            }
            let id = this.$route.params.id;
            this.$axios.post('/api/comments', {
                author: this.commentName,
                content: this.commentText,
                newsId: id
            }).then((response => {
                 window.location.reload();
            }))
        },
        withTag(id){
            this.$router.push('/tag/'+id);
        }
    }
})

</script>
<style scoped></style>