<template >
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">RAF News</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <router-link :to="{name: 'News'}" tag="a" class="nav-link" :class="{active: this.$router.currentRoute.name === 'News'}">News</router-link>
              </li>
              <li class="nav-item">
                <router-link :to="{name: 'PopularNews'}" tag="a" class="nav-link" :class="{active: this.$router.currentRoute.name === 'TopNews'}">Most read News</router-link>
              </li>
              <b-dropdown text="Categories"   variant="primary" class="e-auto mb-2 mb-lg-0" style="height: 35px; margin-top: 5px">
                <b-dropdown-item href="#"  v-for="category in categoryList" :key="category.categoryName"  @click="find(category.id)">{{category.categoryName}}</b-dropdown-item>
              </b-dropdown>
              <li v-if="canLogout" class="nav-item">
                <router-link :to="{name: 'CreatorNews'}" tag="a" class="nav-link" :class="{active: this.$router.currentRoute.name === 'CreatorNews'}">Manage news</router-link>
              </li>
              <li  v-if="canLogout" class="nav-item">
                <router-link :to="{name: 'Categories'}" tag="a" class="nav-link" :class="{active: this.$router.currentRoute.name === 'Categories'}">Manage categories</router-link>
              </li>
              <li v-if="canLogout" class="nav-item">
                <router-link :to="{name: 'AddTag'}" tag="a" class="nav-link" :class="{active: this.$router.currentRoute.name === 'AddTag'}">Add Tag</router-link>
              </li>
              <li v-if="canLogout" class="nav-item">
                <router-link :to="{name: 'Users'}" tag="a" class="nav-link" :class="{active: this.$router.currentRoute.name === 'Users'}">View Users</router-link>
              </li>
            </ul>
            <form v-if="logoutBtn" class="d-flex" @submit.prevent="logout">
              <button class="btn btn-outline-secondary" type="submit">Logout</button>
            </form>
          </div>
        </div>
      </nav>
    </div>
  </template>
  
  <script>
  export default {
    name: "NavigationBar",
    computed: {
      canLogout() {
        return this.$route.name !== 'Login';
      },
      logoutBtn(){
        let auth = localStorage.getItem('auth');
        return this.$route.name !== 'Login' && auth!=null;
      }
    },
    data() {
      return {
        selectedCategory: null,
        categoryList: [],
      }
    },
    mounted() {
      this.$axios.get('/api/category').then((response) => {
        this.categoryList = response.data;
      });
    },
    methods: {
      logout() {
        localStorage.removeItem('auth');
        this.$router.push({name: 'Login'});
      },
      find(name) {
        this.$router.push(`/news/category/${name}`).then(() => {
          window.location.reload();
        });
      }
    }
  }
  </script>
  
  <style scoped>
  
  </style>