import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'
import NewsView from '../views/NewsView.vue'
import PopularNewsView from '../views/PopularNewsView.vue'
import NewsFromCategoryView from '../views/NewsFromCategoryView.vue'
import LoginView from '../views/LoginView.vue'
import AddCategoryView from '../views/AddCategoryView.vue'
import CategoryList from '../views/CategoryList.vue'
import EditCategoryView from '../views/EditCategoryView.vue'
import SingleNewsView from '../views/SingleNewsView.vue'
import UsersListView from '../views/UsersListView.vue'
import AddUserView from '../views/AddUserView.vue'
import EditUserView from '../views/EditUserView.vue'
import CreatorNewsView from '../views/CreatorNewsView.vue'
import AddNewsView from '../views/AddNewsView.vue'
import NewsWithTagView from '../views/NewsWithTagView.vue'
import EditNewsView from '../views/EditNewsView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: NewsView
  },
  {
    path: '/tag/add',
    name: 'AddTag',
    meta: {
      authRequired: true
    },
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AddTagView.vue')
  },
  {
    path: '/tag/:id',
    name: 'NewsWithTag',
    component: NewsWithTagView
  },
  {
    path: '/news',
    name: 'News',
    component: NewsView
  },
  {
    path: '/news/:id',
    name: 'SingleNews',
    component: SingleNewsView
  },
  {
    path: '/news/popular',
    name: 'PopularNews',
    component: PopularNewsView
  },
  {
    path: '/news/category/:id',
    name: 'CategoryNews',
    component: NewsFromCategoryView
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginView
  },
  {
    path: '/categories/add',
    name: 'AddCategory',
    component: AddCategoryView,
    meta: {
      authRequired: true
    }
  },
  {
    path: '/categories',
    name: 'Categories',
    component: CategoryList,
    meta: {
      authRequired: true
    }
  },
  {
    path: '/categories/edit/:id',
    name: 'CategoriesEdit',
    component: EditCategoryView,
    meta: {
      authRequired: true
    }
  },
  {
    path: '/users',
    name: 'Users',
    component: UsersListView,
    meta: {
      authRequired: true,
      adminRequired: true
    }
  },
  {
    path: '/users/add',
    name: 'AddUser',
    component: AddUserView,
    meta: {
      authRequired: true,
      adminRequired: true
    }
  },
  {
    path: '/users/edit/:id',
    name: 'EditUser',
    component: EditUserView,
    meta: {
      authRequired: true,
      adminRequired: true
    }
  },
  {
    path: '/newscreator',
    name: 'CreatorNews',
    component: CreatorNewsView,
    meta: {
      authRequired: true,
      adminRequired: false
    }
  },
  {
    path: '/news/edit/:id',
    name: 'EditNewsView',
    component: EditNewsView,
    meta: {
      authRequired: true,
      adminRequired: false
    }
  },
  {
    path: '/newscreator/add',
    name: 'AddNews',
    component: AddNewsView,
    meta: {
      authRequired: true,
      adminRequired:false
    }
  },
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  if (to.meta.authRequired) {
    const jwt = localStorage.getItem('auth');
    if (!jwt) {
      next({name: 'Login'});
      return;
    }

    const payload = JSON.parse(atob(jwt.split('.')[1]));

    const type = payload.role;
    console.log(type)
    if (to.meta.adminRequired) {
      if (type != 1) {
        alert("Only admin can work with users");
        return;
      }
    }
  }

  next();
});

export default router
